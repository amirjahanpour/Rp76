<?php

use App\Http\Controllers\{HomeController, UsersController};
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [HomeController::class, 'index'])->name('home');

Route::resource("user", UsersController::class)->middleware("auth");

Route::get("zizi", function () {
    $data = \App\Models\State::with("cities")->first();
    foreach ($data->cities as $item) {
        echo $item->name . PHP_EOL;
    }
});