

<?php $__env->startSection("ex-title","User list"); ?>

<?php $__env->startSection("body"); ?>
    <div class="card col-md-12">
        <div class="card-body">
            <?php if(session()->has("msg")): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get("msg")); ?>

                </div>
            <?php endif; ?>
            <a href="<?php echo e(route("user.create")); ?>" class="btn btn-secondary">اضافه کردن کربر</a>
        </div>
    </div>
    <div class="card col-md-12">
        <div class="card-body">
            <table class="table hover table-striped table-responsive-md">
                <thead>
                <tr>
                    <th>شماره</th>
                    <th>عکس</th>
                    <th>نام</th>
                    <th>انتخابات</th>
                    <th>استان</th>
                    <th>شهر</th>
                    <th>شماره ثابت</th>
                    <th>شماره همراه</th>
                    <th>نام کاربری</th>
                    <th>توضیحات</th>
                    <th>کلید ها</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($key+1); ?></td>
                        <td><img src="<?php echo e(asset('/upload/'.$user->image)); ?>" style="width: 6rem"></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->election); ?></td>
                        <td><?php echo e($user->state_id); ?></td>
                        <td><?php echo e($user->city_id); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->mobile); ?></td>
                        <td><?php echo e($user->username); ?></td>
                        <td ><div style="width: 200px;height: 120px;overflow: auto;"><?php echo e($user->resume); ?></div></td>
                        <td>
                            <form action="<?php echo e(route("user.destroy",$user->id)); ?>" method="post">
                                <a href="<?php echo e(route("user.edit",$user->id)); ?>" class="btn btn-warning">ویرایش</a>
                                <?php if(auth()->id() != $user->id): ?>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field("delete"); ?>
                                    <input type="submit" value="حذف" class="btn btn-danger">
                                <?php endif; ?>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <?php echo e($users->links("pagination::bootstrap-4")); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pardis\Desktop\Rp76\resources\views/user/index.blade.php ENDPATH**/ ?>