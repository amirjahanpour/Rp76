<!doctype html>
<html lang="fa">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <link rel="stylesheet" type="text/css" href=<?php echo e(asset('css/bootstrap.rtl.css')); ?>>
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(env("APP_NAME")); ?> <?php if (! empty(trim($__env->yieldContent("ex-title")))): ?>
            - <?php echo $__env->yieldContent("ex-title"); ?>
        <?php endif; ?>
    </title>
    <?php echo $__env->make("layouts.master.css", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body>
<div class="container">
    <div class="row p-3">
        <nav class="navbar navbar-expand-sm bg-light navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item active">

                </li>
            </ul>
        </nav>
    </div>
    <div class="row">
        <?php echo $__env->yieldContent("body"); ?>
    </div>
</div>
<?php echo $__env->make("layouts.master.js", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\Users\pardis\Desktop\Rp76\resources\views/layouts/master/master.blade.php ENDPATH**/ ?>