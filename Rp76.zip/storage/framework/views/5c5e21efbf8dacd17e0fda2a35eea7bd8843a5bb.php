

<?php $__env->startSection("ex-title","Create new user"); ?>

<?php $__env->startSection("body"); ?>
    <div class="card col-md-12">
        <div class="card-body">
            <div class="form-inline">
                <form action="<?php echo e(url('logout')); ?>" method="post">
                    <a href="<?php echo e(route("user.index")); ?>" class="btn btn-secondary">مشاهده کاربر</a>
                    <?php echo csrf_field(); ?>
                    <input CLASS="btn btn-secondary" type="submit" value="خروج">
                </form>
            </div>
        </div>
    </div>
    <div class="card col-md-12">
        <div class="card-body">
            <?php if(session()->has("msg")): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get("msg")); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ol>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route("user.store")); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="font-weight-bold">نام انتخابات<span style="color:red">*</span></label>
                <select name="<?php echo e(\App\Models\User::ELECTION); ?>" class="form-control">
                    <?php $__currentLoopData = \App\Models\User::ELECTION_LIST; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <div class="form-group">
                    <label for="name" class="font-weight-bold">نام و نام خانوادگی<span style="color:red">*</span></label>
                    <input required value="<?php echo e(old(\App\Models\User::NAME)); ?>" type="text" class="form-control"
                           name="<?php echo e(\App\Models\User::NAME); ?>">
                </div>
                <div class="form-group">
                    <label for="phone" class="font-weight-bold">تلفن ثابت همراه با پیش شماره</label>
                    <input value="<?php echo e(old(\App\Models\User::PHONE)); ?>" type="text" class="form-control"
                           name="<?php echo e(\App\Models\User::PHONE); ?>">
                </div>
                <div class="form-group">
                    <label for="mobile" class="font-weight-bold">تلفن همراه </label>
                    <input value="<?php echo e(old(\App\Models\User::MOBILE)); ?>" type="text" class="form-control"
                           name="<?php echo e(\App\Models\User::MOBILE); ?>">
                </div>
                <dev>
                    <label for="name" class="font-weight-bold">لطفا استان و شهر خود را انتخاب کنید</label>
                    <div>
                        <select name="<?php echo e(\App\Models\User::STATE_ID); ?>" class="form-control form-control-lg">
                            <option VALUE="0">لطفا استان را انتخاب کنید</option>
                            <?php $__currentLoopData = $state_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <select name="<?php echo e(\App\Models\User::CITY_ID); ?>" class="form-control">
                            <option VALUE="0">لطفا شهر را انتخاب کنید</option>
                            <?php $__currentLoopData = $city_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-id="<?php echo e($citie->state_id); ?>" value="<?php echo e($citie->id); ?>"><?php echo e($citie->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </dev>
                <div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE); ?>">ارسال عکس شماره یک</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE); ?>">
                    </div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE_TWO); ?>">ارسال عکس شماره دو</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE_TWO); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE_TWO); ?>">
                    </div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE_THREE); ?>">ارسال عکس شماره سه</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE_THREE); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE_THREE); ?>">
                    </div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE_FOUR); ?>">ارسال عکس شماره چهار</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE_FOUR); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE_FOUR); ?>">
                    </div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE_FIVE); ?>">ارسال عکس شماره پنج</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE_FIVE); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE_FIVE); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="username" class="font-weight-bold">نام کاربری</label>
                    <input required value="<?php echo e(old(\App\Models\User::USERNAME)); ?>" type="text" class="form-control"
                           name="<?php echo e(\App\Models\User::USERNAME); ?>">
                </div>
                <div class="form-group">
                    <label for="email" class="font-weight-bold">ایمیل</label>
                    <input value="<?php echo e(old(\App\Models\User::EMAIL)); ?>" type="email" class="form-control"
                           name="<?php echo e(\App\Models\User::EMAIL); ?>">
                </div>
                <div class="form-group">
                    <label for="password" class="font-weight-bold">رمز عبور</label>
                    <input required type="password" class="form-control" name="<?php echo e(\App\Models\User::PASSWORD); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1" class="font-weight-bold">ارسال رزومه، سوابق ،زندگی نامه ...</label>
                    <textarea class="form-control" name="<?php echo e(\App\Models\User::RESUME); ?>" id="exampleFormControlTextarea1" rows="3"></textarea>
                </div>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="customCheck1" name="obligation">
                    <label class="custom-control-label font-weight-bold" for="customCheck1"><span style="color:red">*</span>مسئولیت صحت و سقم تمامی موارد ارسال شده بر
                        عهده اینجانب می باشد</label>
                </div>
                <input type="submit" style="margin-bottom: 20px; margin-top: 12px" value="ثبت" class="btn btn-success rounded">
            </div>
        </form>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('ex-js'); ?>
            <script>
                $(document).ready(function () {
                    $("[name='<?php echo e(\App\Models\User::CITY_ID); ?>']").find("option").hide();
                })

                $("[name='<?php echo e(\App\Models\User::STATE_ID); ?>']").change(function () {
                    const id = $(this).val();
                    $("[name='<?php echo e(\App\Models\User::CITY_ID); ?>']").find("option").hide();
                    $("[name='<?php echo e(\App\Models\User::CITY_ID); ?>']").find("option").each(function (index, item) {
                        if ($(item).data("id") == id)
                            $(item).show();
                    });
                })
            </script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pardis\Desktop\Rp76\resources\views/user/create.blade.php ENDPATH**/ ?>