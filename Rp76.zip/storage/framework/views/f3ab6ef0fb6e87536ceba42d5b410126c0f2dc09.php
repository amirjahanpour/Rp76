

<?php $__env->startSection("ex-title","Create new user"); ?>

<?php $__env->startSection("body"); ?>
    <div class="card col-md-12">
        <div class="card-body">
            <div class="form-inline">
                <form action="<?php echo e(url('logout')); ?>" method="post">
                    <?php if(Illuminate\Support\Facades\Auth::user()->is_admin==1): ?>
                    <a href="<?php echo e(route("user.index")); ?>" class="btn btn-secondary">مشاهده کاربر</a>
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <input CLASS="btn btn-secondary" type="submit" value="خروج">
                </form>
            </div>
        </div>
    </div>
    <div class="card col-md-12">
        <div class="card-body">
            <?php if(session()->has("msg")): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get("msg")); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ol>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
            <?php endif; ?>
        </div>
        <div>
            <p class="font-weight-bold">عکس قبلی شما :</p>
            <div>
                        <div id="carouselExampleSlidesOnly" class="carousel" data-interval="3000" data-ride="carousel">
                            <div class="carousel-inner">
                                <?php if($user->image != 'img.png'): ?>
                                <div class="carousel-item active">
                                    <img class="d-block w-25" src="<?php echo e(asset('/upload/'.$user->image)); ?>" alt="First slide">
                                </div>
                                <?php endif; ?>
                                    <?php if($user->image_two != 'img.png'): ?>
                                <div class="carousel-item">
                                    <img class="d-block w-25" src="<?php echo e(asset('/upload/'.$user->image_two)); ?>" alt="Second slide">
                                </div>
                                    <?php endif; ?>
                                    <?php if($user->image_three != 'img.png'): ?>
                                <div class="carousel-item">
                                    <img class="d-block w-25" src="<?php echo e(asset('/upload/'.$user->image_three)); ?>" alt="Third slide">
                                </div>
                                    <?php endif; ?>
                                    <?php if($user->image_four != 'img.png'): ?>
                                <div class="carousel-item">
                                    <img class="d-block w-25" src="<?php echo e(asset('/upload/'.$user->image_four)); ?>" alt="Third slide">
                                </div>
                                    <?php endif; ?>
                                    <?php if($user->image_five != 'img.png'): ?>
                                <div class="carousel-item">
                                    <img class="d-block w-25" src="<?php echo e(asset('/upload/'.$user->image_five)); ?>" alt="Third slide">
                                </div>
                                    <?php endif; ?>
                            </div>
                        </div>
            </div>
        </div>
        <form action="<?php echo e(route("user.update",$user->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field("put"); ?>
            <div class="form-group">
                <label style="margin-top: 1rem" class="font-weight-bold">نام انتخابات<span style="color:red">*</span></label>
                <select name="<?php echo e(\App\Models\User::ELECTION); ?>" class="form-control" >
                    <option value="<?php echo e($user->election); ?>"><?php echo e(@\App\Models\User::ELECTION_LIST[$user->election]); ?></option>
                    <?php $__currentLoopData = \App\Models\User::ELECTION_LIST; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div>
                <div class="form-group">
                    <label for="name" class="font-weight-bold">نام و نام خانوادگی<span style="color:red">*</span></label>
                    <input required value="<?php echo e(old(\App\Models\User::NAME,$user->name)); ?>" type="text" class="form-control" name="<?php echo e(\App\Models\User::NAME); ?>">
                </div>
                <div class="form-group">
                    <label for="phone" class="font-weight-bold">تلفن ثابت همراه با پیش شماره</label>
                    <input value="<?php echo e(old(\App\Models\User::PHONE,$user->phone)); ?>" type="text" class="form-control" name="<?php echo e(\App\Models\User::PHONE); ?>">
                </div>
                <div class="form-group">
                    <label for="mobile" class="font-weight-bold">تلفن همراه</label>
                    <input value="<?php echo e(old(\App\Models\User::MOBILE,$user->mobile)); ?>" type="text" class="form-control" name="<?php echo e(\App\Models\User::MOBILE); ?>">
                </div>
                <div>
                     <label for="name" class="font-weight-bold">لطفا استان و شهر خود را انتخاب کنید</label>
                        <div>
                            <select name="<?php echo e(\App\Models\User::STATE_ID); ?>" class="form-control form-control-lg">
                                <option VALUE="<?php echo e($user->state_id); ?>"><?php echo e(@$user->state->name); ?></option>
                                <?php $__currentLoopData = $state_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div>
                            <select name="<?php echo e(\App\Models\User::CITY_ID); ?>" class="form-control">
                                <option VALUE="<?php echo e($user->city_id); ?>"><?php echo e(@$user->city->name); ?></option>
                                <?php $__currentLoopData = $city_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option data-id="<?php echo e($citie->state_id); ?>" value="<?php echo e($citie->id); ?>"><?php echo e($citie->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                </div>
                <div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE); ?>">ارسال عکس شماره یک</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE); ?>">
                    </div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE_TWO); ?>">ارسال عکس شماره دو</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE_TWO); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE_TWO); ?>">
                    </div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE_THREE); ?>">ارسال عکس شماره سه</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE_THREE); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE_THREE); ?>">
                    </div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE_FOUR); ?>">ارسال عکس شماره چهار</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE_FOUR); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE_FOUR); ?>">
                    </div>
                    <div class="form-group">
                        <label style="margin-top: 12px;" class="font-weight-bold" for="<?php echo e(\App\Models\User::IMAGE_FIVE); ?>">ارسال عکس شماره پنج</label>
                        <input name="<?php echo e(\App\Models\User::IMAGE_FIVE); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE_FIVE); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label for="username" class="font-weight-bold">نام کاربری</label>
                    <input required value="<?php echo e(old(\App\Models\User::USERNAME,$user->username)); ?>" type="text" class="form-control" name="<?php echo e(\App\Models\User::USERNAME); ?>">
                </div>
                <div class="form-group">
                    <label class="font-weight-bold" for="email">ایمیل</label>
                    <input value="<?php echo e(old(\App\Models\User::EMAIL,$user->email)); ?>" type="email" class="form-control" name="<?php echo e(\App\Models\User::EMAIL); ?>">
                </div>
                <div class="form-group">
                    <label class="font-weight-bold" for="password">رمز عبور</label>
                    <input type="password" class="form-control" name="<?php echo e(\App\Models\User::PASSWORD); ?>">
                </div>
                <div class="form-group">
                    <label class="font-weight-bold" for="exampleFormControlTextarea1">ارسال رزومه، سوابق ،زندگی نامه ...</label>
                    <textarea class="form-control" name="<?php echo e(\App\Models\User::RESUME); ?>" id="exampleFormControlTextarea1" rows="3"><?php echo e($user->resume); ?></textarea>
                </div>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="customCheck1" name="obligation">
                    <label class="custom-control-label font-weight-bold" for="customCheck1">مسئولیت صحت و سقم تمامی موارد ارسال شده بر عهده اینجانب می باشد <span style="color:red"> *</span> </label>
                </div>
                <input type="submit" style="margin-bottom: 20px; margin-top: 12px" value="ثبت" class="btn btn-success rounded">
            </div>
        </form>
<?php $__env->stopSection(); ?>
        <?php $__env->startSection('ex-js'); ?>
            <script>
                $(document).ready(function () {
                    $("[name='<?php echo e(\App\Models\User::CITY_ID); ?>']").find("option").hide();
                })

                $("[name='<?php echo e(\App\Models\User::STATE_ID); ?>']").change(function () {
                    const id = $(this).val();
                    $("[name='<?php echo e(\App\Models\User::CITY_ID); ?>']").find("option").hide();
                    $("[name='<?php echo e(\App\Models\User::CITY_ID); ?>']").find("option").each(function (index, item) {
                        if ($(item).data("id") == id)
                            $(item).show();
                    });
                })
            </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pardis\Desktop\Rp76\resources\views/user/edit.blade.php ENDPATH**/ ?>