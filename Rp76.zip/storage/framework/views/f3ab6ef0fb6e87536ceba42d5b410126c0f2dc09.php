

<?php $__env->startSection("ex-title","Create new user"); ?>

<?php $__env->startSection("body"); ?>
    <div class="card col-md-12">
        <div class="card-body">
            <a href="<?php echo e(route("user.index")); ?>" class="btn btn-secondary">مشاهده کاربر</a>
        </div>
    </div>
    <div class="card col-md-12">
        <div class="card-body">
            <?php if(session()->has("msg")): ?>
                <div class="alert alert-success">
                    <?php echo e(session()->get("msg")); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ol>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
            <?php endif; ?>
        </div>
        <div>
            <p>عکس قبلی شما :</p>
            <img src="<?php echo e(asset('/upload/'.$user->image)); ?>" style="width: 10rem">
        </div>
        <form action="<?php echo e(route("user.update",$user->id)); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field("put"); ?>
            <div class="form-group">
                <label style="margin-top: 1rem">نام انتخابات</label>
                <select name="<?php echo e(\App\Models\User::ELECTION); ?>" class="form-control" >
                    <option value="<?php echo e($user->election); ?>"></option>
                    <option value="1">انتخابات ریاست جمهوری</option>
                    <option value="2">انتخابات مجلس خبرگان رهبری</option>
                    <option value="3">انتخابات مجلس شورای اسلامی</option>
                    <option value="4">انتخابات شورای اسلامی شهر و روستا</option>
                </select>
            </div>
            <div>
                <div class="form-group">
                    <label for="name">Fullname : </label>
                    <input required value="<?php echo e(old(\App\Models\User::NAME,$user->name)); ?>" type="text" class="form-control" name="<?php echo e(\App\Models\User::NAME); ?>">
                </div>
                <dev>
                    <label for="name" class="text-center">لطفا استان و شهر خود را انتخاب کنید</label>
                    <div>
                        <select name="<?php echo e(\App\Models\User::STATE_ID); ?>" class="form-control form-control-lg" onChange="iranwebsv(this.value);">
                            <option VALUE="0">لطفا استان را انتخاب کنید</option>
                            <?php $__currentLoopData = $state_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($state->id); ?>"><?php echo e($state->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div>
                        <select name="<?php echo e(\App\Models\User::CITY_ID); ?>" class="form-control" onChange="iranwebsv(this.value);">
                            <option VALUE="0">لطفا شهر را انتخاب کنید</option>
                            <?php $__currentLoopData = $city_select; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option data-id="" value="<?php echo e($citie->id); ?>"><?php echo e($citie->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </dev>
                <div class="form-group">
                    <label style="margin-top: 12px;" for="<?php echo e(\App\Models\User::IMAGE); ?>">ارسال عکس</label>
                    <input name="<?php echo e(\App\Models\User::IMAGE); ?>" type="file" class="form-control" id="<?php echo e(\App\Models\User::IMAGE); ?>">
                </div>
                <div class="form-group">
                    <label for="username">نام کاربری</label>
                    <input required value="<?php echo e(old(\App\Models\User::USERNAME,$user->username)); ?>" type="text" class="form-control" name="<?php echo e(\App\Models\User::USERNAME); ?>">
                </div>
                <div class="form-group">
                    <label for="email">ایمیل</label>
                    <input required value="<?php echo e(old(\App\Models\User::EMAIL,$user->email)); ?>" type="email" class="form-control" name="<?php echo e(\App\Models\User::EMAIL); ?>">
                </div>
                <div class="form-group">
                    <label for="password">رمز عبور</label>
                    <input type="password" class="form-control" name="<?php echo e(\App\Models\User::PASSWORD); ?>">
                </div>
                <div class="form-group">
                    <label for="exampleFormControlTextarea1">ارسال رزومه، سوابق ،زندگی نامه ...</label>
                    <textarea class="form-control" name="<?php echo e(\App\Models\User::RESUME); ?>" id="exampleFormControlTextarea1" rows="3"><?php echo e($user->resume); ?></textarea>
                </div>
                <div class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" id="customCheck1">
                    <label class="custom-control-label" for="customCheck1">مسئولیت صحت و سقم تمامی موارد ارسال شده بر عهده اینجانب می باشد</label>
                </div>
                <input type="submit" value="Edit" class="btn btn-success rounded">
            </div>
        </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.master.master", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pardis\Desktop\Rp76\resources\views/user/edit.blade.php ENDPATH**/ ?>