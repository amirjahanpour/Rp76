<script src="{{asset("js/app.js")}}"></script>
@yield("ex-js")